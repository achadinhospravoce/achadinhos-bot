# Achadinhos Pra Você — versão inicial

Painel web simples para pesquisar produtos do Mercado Livre e filtrar pelo desconto exibido.

## Arquivos
- app.py
- requirements.txt
- Procfile
- render.yaml

## Rodar localmente
pip install -r requirements.txt
python app.py

## Observação de segurança
Não coloque Client Secret dentro desses arquivos. Em uma próxima etapa, qualquer chave será salva como variável secreta no serviço de nuvem.
