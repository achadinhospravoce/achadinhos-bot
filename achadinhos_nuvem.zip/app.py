from __future__ import annotations

import os
from typing import Any

import requests
from flask import Flask, render_template_string, request

app = Flask(__name__)

HTML = """
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Achadinhos Pra Você</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; background: #fff7f2; color: #2c1b16; }
    header { background: #ff6b3d; color: white; padding: 18px; text-align: center; }
    main { max-width: 900px; margin: auto; padding: 16px; }
    form { background: white; padding: 16px; border-radius: 14px; box-shadow: 0 2px 10px #0001; }
    input, button { width: 100%; box-sizing: border-box; padding: 12px; margin-top: 8px; border-radius: 10px; }
    input { border: 1px solid #ddd; }
    button { border: 0; background: #ff6b3d; color: white; font-weight: bold; cursor: pointer; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px; margin-top: 18px; }
    .card { background: white; border-radius: 14px; padding: 12px; box-shadow: 0 2px 10px #0001; }
    .card img { width: 100%; aspect-ratio: 1/1; object-fit: contain; border-radius: 10px; }
    .old { text-decoration: line-through; color: #777; }
    .price { font-size: 1.35rem; font-weight: bold; color: #d9481c; }
    .discount { display: inline-block; background: #e7f7ea; color: #187a2f; padding: 5px 8px; border-radius: 8px; font-weight: bold; }
    a { text-decoration: none; }
    .open { display: block; text-align: center; margin-top: 10px; padding: 10px; background: #ff6b3d; color: white; border-radius: 10px; }
    .error { background: #ffe3e3; padding: 12px; border-radius: 10px; margin-top: 15px; }
  </style>
</head>
<body>
<header>
  <h1>🛍️ Achadinhos Pra Você</h1>
  <p>Caçador inicial de ofertas do Mercado Livre</p>
</header>
<main>
  <form method="get">
    <label>Produto para procurar</label>
    <input name="q" value="{{ query }}" placeholder="Ex.: air fryer, televisão, perfume" required>
    <label>Desconto mínimo (%)</label>
    <input name="min_discount" type="number" min="0" max="90" value="{{ min_discount }}">
    <button type="submit">🔎 Procurar ofertas</button>
  </form>

  {% if error %}
    <div class="error">{{ error }}</div>
  {% endif %}

  {% if results %}
    <div class="grid">
    {% for item in results %}
      <div class="card">
        <img src="{{ item.thumbnail }}" alt="{{ item.title }}">
        <h3>{{ item.title }}</h3>
        {% if item.original_price %}
          <div class="old">De R$ {{ item.original_price }}</div>
        {% endif %}
        <div class="price">R$ {{ item.price }}</div>
        {% if item.discount > 0 %}
          <span class="discount">{{ item.discount }}% OFF</span>
        {% endif %}
        <a class="open" href="{{ item.permalink }}" target="_blank" rel="noopener">Abrir produto</a>
      </div>
    {% endfor %}
    </div>
  {% elif query and not error %}
    <p>Nenhum produto encontrado com o desconto escolhido.</p>
  {% endif %}
</main>
</body>
</html>
"""

def brl(value: float | int | None) -> str:
    if value is None:
        return ""
    return f"{float(value):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def calcular_desconto(preco: float, original: float | None) -> int:
    if not original or original <= preco:
        return 0
    return round((1 - preco / original) * 100)

def buscar_produtos(query: str, min_discount: int) -> list[dict[str, Any]]:
    url = "https://api.mercadolibre.com/sites/MLB/search"
    response = requests.get(
        url,
        params={"q": query, "limit": 50},
        timeout=20,
        headers={"User-Agent": "AchadinhosPraVoce/1.0"},
    )
    response.raise_for_status()
    data = response.json()

    produtos: list[dict[str, Any]] = []
    for raw in data.get("results", []):
        price = raw.get("price")
        original = raw.get("original_price")
        if price is None:
            continue
        discount = calcular_desconto(float(price), float(original) if original else None)
        if discount < min_discount:
            continue

        thumbnail = (raw.get("thumbnail") or "").replace("http://", "https://")
        produtos.append(
            {
                "title": raw.get("title", "Produto"),
                "price": brl(price),
                "original_price": brl(original) if original else "",
                "discount": discount,
                "thumbnail": thumbnail,
                "permalink": raw.get("permalink", "#"),
            }
        )

    produtos.sort(key=lambda x: x["discount"], reverse=True)
    return produtos[:30]

@app.get("/")
def home():
    query = request.args.get("q", "").strip()
    try:
        min_discount = max(0, min(90, int(request.args.get("min_discount", "10"))))
    except ValueError:
        min_discount = 10

    results: list[dict[str, Any]] = []
    error = ""

    if query:
        try:
            results = buscar_produtos(query, min_discount)
        except requests.RequestException as exc:
            error = f"Não foi possível consultar o Mercado Livre agora: {exc}"

    return render_template_string(
        HTML,
        query=query,
        min_discount=min_discount,
        results=results,
        error=error,
    )

@app.get("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
